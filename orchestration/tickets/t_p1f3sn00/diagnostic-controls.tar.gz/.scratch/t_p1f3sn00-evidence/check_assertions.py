"""Compare original case assertion ASTs and literal timeout arguments against the patch."""
import ast
import collections
import json
from pathlib import Path
import subprocess

BASE = '6187155312de4d1b4fd34c272dfa5e2096808b6c'
FILES = [f'web/tests/browser/cases/{name}.py' for name in ('workspace-utility-pane', 'conversation-pane')]
results = {}
for name in FILES:
    before = ast.parse(subprocess.check_output(['git', 'show', f'{BASE}:{name}'], text=True))
    after = ast.parse(Path(name).read_text())
    def assertions(tree):
        return collections.Counter(ast.dump(node, include_attributes=False) for node in ast.walk(tree) if isinstance(node, ast.Assert))
    def expects(tree):
        return collections.Counter(ast.dump(node, include_attributes=False) for node in ast.walk(tree) if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and 'expect(' in ast.unparse(node))
    missing_asserts = assertions(before) - assertions(after)
    missing_expects = expects(before) - expects(after)
    results[name] = {'original_assertions':sum(assertions(before).values()), 'original_expect_expressions':sum(expects(before).values()), 'missing_assertions':list(missing_asserts.elements()), 'missing_expect_expressions':list(missing_expects.elements())}
    assert not missing_asserts and not missing_expects, results[name]
Path('.scratch/t_p1f3sn00-evidence/assertion-preservation.json').write_text(json.dumps(results, indent=2)+'\n')
print(json.dumps(results,indent=2))

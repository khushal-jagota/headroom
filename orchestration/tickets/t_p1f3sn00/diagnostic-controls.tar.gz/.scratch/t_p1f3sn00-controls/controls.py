import json
import runpy
import sys
import time
import platform
from pathlib import Path
from urllib.parse import parse_qs,urlsplit
from playwright.sync_api import sync_playwright,expect
ROOT=Path.cwd()
OUT=ROOT/'.scratch/t_p1f3sn00-controls'
sys.path.insert(0,str(ROOT))
fixture=runpy.run_path(str(ROOT/'web/tests/support/navigation/browser-fixture.py'))
barriers=runpy.run_path(str(ROOT/'web/tests/browser/support/state_barriers.py'))
results=[]
state={'recap':'Initial recap','id':'control_worker'}
def respond(route):
    parts=urlsplit(route.request.url); path=parts.path
    if path=='/api/navigation/view/snapshot':
        worker={'id':state['id'],'title':'Control worker','worker_type':'coding','stage':'needs_implementation','ticket_status':'agent','recap':state['recap']}
        source=fixture['navigation_response']({'managers':[{'id':'control_manager','title':'Control manager','created_at':1,'tickets':[worker]}]},{'chief_of_staff':{'label':'Chief','conversation_id':'bounded-reader'}})
        route.fulfill(json=fixture['scoped_navigation_response'](source,json.loads(parse_qs(parts.query)['view'][0]))); return
    key=parse_qs(parts.query).get('key',[path])[0] if path=='/api/resource-body' else path
    body={
       '/api/workers/chief-of-staff/settings':{'employee_id':'chief','label':'Chief','recap':'Reader control','skill':None,'launch_defaults':{'employee_backend':'codex','employee_launch_model':None,'employee_launch_reasoning_effort':None}},
       '/api/chief/conversation/start-values':{'backend_key':'codex','model':None,'reasoning_effort':None},
       '/api/worker-types?supported=true':{'worker_types':[]},'/api/worker-types':{'worker_types':[]},'/api/workers':{'workers':[],'chief_of_staff':{'label':'Chief'}},'/api/skills':{'skills':[]},'/api/feedback/count':{'open_count':0},'/api/meta':{'test_mode':True,'app_sha':None},'/api/review':{'items':[],'running_worker_count':0},'/api/deployment-status':{'state':'idle','deployed_sha':None,'target_sha':None,'outcome':None,'detail':None,'valid_until':None},
    }.get(key,{})
    route.fulfill(json={'key':key,'epoch':'controls','revision':'1','body':body} if path=='/api/resource-body' else body)

def record(name,fn,expected_failure=False,contains=None):
    start=time.monotonic()
    try:
        evidence=fn()
        if expected_failure:raise RuntimeError('Expected setup refusal did not occur')
        results.append({'name':name,'status':'expected-success','seconds':time.monotonic()-start,'evidence':evidence})
    except Exception as exc:
        if not expected_failure or (contains and contains not in str(exc)):
            results.append({'name':name,'status':'unexpected-failure','seconds':time.monotonic()-start,'error':repr(exc)})
            (OUT/'results.json').write_text(json.dumps(results,indent=2));raise
        results.append({'name':name,'status':'expected-setup-failure','seconds':time.monotonic()-start,'error':str(exc)})
    (OUT/'results.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results[-1]),flush=True)

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    context=browser.new_context(viewport={'width':1280,'height':800},reduced_motion='reduce')
    page=context.new_page();page.route('**/api/**',respond)
    page.goto(sys.argv[1]+'?overlay=1#/workspace/chief-of-staff',wait_until='domcontentloaded')
    expect(page.locator('[data-conversation-input]')).to_be_visible()
    pane=page.locator('[data-conversation-pane]')
    if pane.get_attribute('data-conversation-state')!='opened':page.locator('[data-conversation-expand]').click()
    thread=page.locator('[data-conversation-thread]');expect(thread).to_be_visible()
    thread.focus();page.keyboard.press('End')
    page.wait_for_function("()=>{const e=document.querySelector('[data-conversation-thread]');return e&&e.scrollHeight-e.clientHeight-e.scrollTop<=1&&e.dataset.conversationPlacementReady==='true'}")
    thread.hover()
    page.evaluate("()=>{window.__wheelCount=0;window.__suppress=e=>{window.__wheelCount++;e.preventDefault()};document.querySelector('[data-conversation-thread]').addEventListener('wheel',window.__suppress,{capture:true,passive:false})}")
    record('one-suppressed-native-wheel',lambda:barriers['establish_scrollback'](page,lambda:page.mouse.wheel(0,-650),min_clearance=2),True)
    assert page.evaluate('window.__wheelCount')==1
    assert thread.evaluate('e=>e.scrollHeight-e.clientHeight-e.scrollTop')<=1
    page.evaluate("()=>document.querySelector('[data-conversation-thread]').removeEventListener('wheel',window.__suppress,true)")
    record('valid-native-wheel',lambda:barriers['establish_scrollback'](page,lambda:page.mouse.wheel(0,-650),min_clearance=2))
    # The existing App host also owns the recap rail and its production projection.
    page.goto(sys.argv[1]+'#/workspace/utility/settings',wait_until='domcontentloaded')
    expect(page.locator('[data-ticket-id="control_worker"]')).to_be_visible()
    selector='[data-ticket-id="control_worker"] .card-title'
    record('baseline-projection',lambda:barriers['refresh_projection'](page))
    page.evaluate('window.__originalRefresh=window.__refreshNavigation;window.__holdNavigation=true')
    record('held-publication',lambda:barriers['refresh_projection'](page),True)
    page.evaluate('window.__holdNavigation=false;window.__releaseNavigation()')
    record('post-timeout-clean-refresh',lambda:barriers['refresh_projection'](page))
    # Preserve an old DOM while a fresh receipt still names the new snapshot.
    page.evaluate("()=>{window.__refreshNavigation=async options=>{const receipts=await window.__originalRefresh(options);document.querySelector('[data-ticket-id=control_worker]').dataset.ticketId='stale_worker';return receipts}}")
    record('stale-membership',lambda:barriers['refresh_projection'](page),True)
    page.evaluate("()=>{window.__refreshNavigation=window.__originalRefresh;document.querySelector('[data-ticket-id=stale_worker]').dataset.ticketId='control_worker'}")
    row=page.locator('[data-ticket-id="control_worker"]');row.hover()
    expect(page.locator('[data-rail-hover-panel]')).to_have_attribute('aria-hidden','false')
    record('stale-content',lambda:barriers['refresh_projection'](page,required_content=[{'selector':'[data-rail-hover-panel] [data-recap-text]','text':'Expected updated recap'}]),True)
    page.evaluate("()=>{window.__refreshNavigation=async options=>{const receipts=await window.__originalRefresh(options);window.__navigationSources()[0].close();return receipts}}")
    record('closed-source',lambda:barriers['refresh_projection'](page),True)
    page.reload(wait_until='domcontentloaded');expect(page.locator('[data-ticket-id="control_worker"]')).to_be_visible()
    page.evaluate("()=>{window.__originalRefresh=window.__refreshNavigation;window.__refreshNavigation=async options=>{const receipts=await window.__originalRefresh(options);const source=window.__navigationSources()[0];source.close();new EventSource(source.url);return receipts}}")
    record('replaced-source',lambda:barriers['refresh_projection'](page),True)
    page.reload(wait_until='domcontentloaded');expect(page.locator('[data-ticket-id="control_worker"]')).to_be_visible()
    state['id']='delayed_worker'
    page.evaluate("()=>{const source=window.__navigationSources()[0];const original=source.listeners.get('snapshot');source.listeners.set('snapshot',event=>{window.__delayedDispatchReceiptAt=performance.now();setTimeout(()=>{original(event);window.__delayedDomDispatchAt=performance.now()},350)})}")
    t=time.monotonic()
    record('delayed-valid-snapshot',lambda:barriers['refresh_projection'](page))
    assert time.monotonic()-t>=.25
    expect(page.locator('[data-ticket-id="delayed_worker"]')).to_be_visible()
    expect(page.locator('[data-ticket-id="control_worker"]')).to_have_count(0)
    page.screenshot(path=str(OUT/'delayed-valid-admission.png'))
    (OUT/'runtime.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'browser':browser.version,'diagnostic_only':True,'catalog_receipt':False},indent=2))
    context.close();browser.close()

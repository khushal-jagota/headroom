import json
import runpy
import sys
import time
import platform
from pathlib import Path
from urllib.parse import parse_qs,urlsplit
from playwright.sync_api import sync_playwright,expect
ROOT=Path.cwd()
OUT=ROOT/'.scratch/t_p1f3sn00-controls'
sys.path.insert(0,str(ROOT))
fixture=runpy.run_path(str(ROOT/'web/tests/support/navigation/browser-fixture.py'))
barriers=runpy.run_path(str(ROOT/'.scratch/t_p1f3sn00-evidence/state_barriers.http-status.py'))
results=[]
state={'recap':'Initial recap','id':'control_worker'}
def respond(route):
    parts=urlsplit(route.request.url); path=parts.path
    if path=='/api/navigation/view/snapshot' and state.get('http503'):
        state['refusals']=state.get('refusals',0)+1;route.fulfill(status=503,json={'error':{'code':'diagnostic','message':'HTTP503 control'}});return
    if path=='/api/navigation/view/snapshot':
        worker={'id':state['id'],'title':'Control worker','worker_type':'coding','stage':'needs_implementation','ticket_status':'agent','recap':state['recap']}
        source=fixture['navigation_response']({'managers':[{'id':'control_manager','title':'Control manager','created_at':1,'tickets':[worker]}]},{'chief_of_staff':{'label':'Chief','conversation_id':'bounded-reader'}})
        route.fulfill(json=fixture['scoped_navigation_response'](source,json.loads(parse_qs(parts.query)['view'][0]))); return
    key=parse_qs(parts.query).get('key',[path])[0] if path=='/api/resource-body' else path
    body={
       '/api/workers/chief-of-staff/settings':{'employee_id':'chief','label':'Chief','recap':'Reader control','skill':None,'launch_defaults':{'employee_backend':'codex','employee_launch_model':None,'employee_launch_reasoning_effort':None}},
       '/api/chief/conversation/start-values':{'backend_key':'codex','model':None,'reasoning_effort':None},
       '/api/worker-types?supported=true':{'worker_types':[]},'/api/worker-types':{'worker_types':[]},'/api/workers':{'workers':[],'chief_of_staff':{'label':'Chief'}},'/api/skills':{'skills':[]},'/api/feedback/count':{'open_count':0},'/api/meta':{'test_mode':True,'app_sha':None},'/api/review':{'items':[],'running_worker_count':0},'/api/deployment-status':{'state':'idle','deployed_sha':None,'target_sha':None,'outcome':None,'detail':None,'valid_until':None},
    }.get(key,{})
    route.fulfill(json={'key':key,'epoch':'controls','revision':'1','body':body} if path=='/api/resource-body' else body)

def record(name,fn,expected_failure=False,contains=None):
    start=time.monotonic()
    try:
        evidence=fn()
        if expected_failure:raise RuntimeError('Expected setup refusal did not occur')
        results.append({'name':name,'status':'expected-success','seconds':time.monotonic()-start,'evidence':evidence})
    except Exception as exc:
        if not expected_failure or (contains and contains not in str(exc)):
            results.append({'name':name,'status':'unexpected-failure','seconds':time.monotonic()-start,'error':repr(exc)})
            (OUT/'results-http503.json').write_text(json.dumps(results,indent=2));raise
        results.append({'name':name,'status':'expected-setup-failure','seconds':time.monotonic()-start,'error':str(exc)})
    (OUT/'results-http503.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results[-1]),flush=True)

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    context=browser.new_context(viewport={'width':1280,'height':800})
    page=context.new_page();page.route('**/api/**',respond)
    errors=[];page.on('pageerror',lambda error:errors.append(str(error)))
    page.goto(sys.argv[1]+'#/workspace/utility/settings',wait_until='domcontentloaded')
    expect(page.locator('[data-ticket-id="control_worker"]')).to_be_visible()
    # Establish initial source before the independent background HTTP fault.
    page.wait_for_function("()=>window.__navigationSources().length===1&&JSON.parse(new URL(window.__navigationSources()[0].url,location.href).searchParams.get('view')).windows.some(w=>w.section==='rail_tickets'&&w.owner?.id==='control_manager')")
    before=list(errors);state['http503']=True
    page.evaluate("()=>{window.__backgroundHttpReceipt=null;void window.__navigationSources()[0].refresh().then(receipt=>window.__backgroundHttpReceipt=receipt)}")
    page.wait_for_function('window.__backgroundHttpReceipt!==null')
    page.evaluate('()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)))')
    background=page.evaluate('window.__backgroundHttpReceipt')
    assert background['dispatched'] is False and background['status']==503 and background['snapshot'] is None,background
    assert errors==before,errors
    record('explicit-refresh-refuses-HTTP503',lambda:barriers['refresh_projection'](page),True)
    error=results[-1]['error']
    assert "'status': 503" in error and "'dispatched': False" in error and "'snapshot': None" in error,error
    assert errors==before,errors
    (OUT/'http503-details.json').write_text(json.dumps({'background_receipt':background,'page_errors_before':before,'page_errors_after':errors,'http503_responses':state['refusals'],'browser':browser.version,'fixture_module':'.scratch/t_p1f3sn00-evidence/workspace-utility-pane.http-status.mjs','helper_module':'.scratch/t_p1f3sn00-evidence/state_barriers.http-status.py'},indent=2))
    context.close();browser.close()

import json
import os
import runpy
import subprocess
import sys
import time
import traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path.cwd()
OUT=ROOT/'.scratch/t_p1f3sn00-controls/full-workspace'
OUT.mkdir(parents=True,exist_ok=True)
os.environ['PANELS_SIDEBAR_ARTIFACT_DIR']=str(OUT/'artifacts')
os.environ['PANELS_VPS_ARTIFACT_DIR']=str(OUT/'vps')
sys.path.insert(0,str(ROOT))
start=time.monotonic()
result={'scope':'Direct existing workspace-utility-pane.run diagnostic; no catalog receipt','revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'status':'failed'}
try:
    case=runpy.run_path(str(ROOT/'web/tests/browser/cases/workspace-utility-pane.py'))
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True)
        result['browser']=browser.version
        try:case['run'](browser,[sys.argv[1]])
        finally:browser.close()
    result['status']='passed'
except Exception:
    result['error']=traceback.format_exc()
    raise
finally:
    result['seconds']=time.monotonic()-start
    (OUT/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    print('DIRECT_WORKSPACE_DIAGNOSTIC '+json.dumps(result),flush=True)

Diagnostic controls for shared state barriers. These scripts invoke the existing workspace App prepare function and the existing bounded reader fixture. They create no catalog case or gate receipt. All services bind port zero and close their exact server instance. Runtime strips live PLAN_ paths and uses this worktree Python. No files under Deployments were written.

Commands (from worktree root):
- node .scratch/t_p1f3sn00-controls/run.mjs > .scratch/t_p1f3sn00-controls/run.log 2>&1
- node .scratch/t_p1f3sn00-controls/run-delayed.mjs > .scratch/t_p1f3sn00-controls/run-delayed.log 2>&1
- node .scratch/t_p1f3sn00-controls/run-recap.mjs > .scratch/t_p1f3sn00-controls/run-recap.log 2>&1
- node .scratch/t_p1f3sn00-controls/run-wheel-final.mjs > .scratch/t_p1f3sn00-controls/run-wheel-final.log 2>&1

results.json includes nine expected setup refusals/successes and one unexpected delayed-listener diagnostic failure. That final injection falsely marks dispatch complete before the production listener runs. The corrected supported delay control uses the fixture delivery delay and a DOM MutationObserver. results-supplement.json and supplement.json record its pass, exact admission timestamp, and held queue cleanup. The original failure remains here as diagnostic history and is not a product failure.

Full existing recap function smoke is a separate check. Its initial failure exposes legitimate source replacement during initial manager-child subscription discovery, before recap motion checks. Source worker received this finding.

Full existing recap proof passes after source setup repair: 31.883 seconds. It retains pointer, keyboard, mid-shrink, scroll dismissal, and touch assertions. Module load precedes the final one-line initial touch refresh addition; root complete catalog checks final source. summary.json consolidates selected controls and runtime facts without erasing diagnostic history.

Event-order correction diagnostic (scratch saved module only, source freeze preserved):
node .scratch/t_p1f3sn00-controls/run-event-order.mjs > .scratch/t_p1f3sn00-controls/run-event-order.log 2>&1

Both controls use genuine native PageUp. Same-position synthetic scroll notification after trusted native completion passes. Deliberate 37px post-completion displacement immediately invalidates completion and all three direct sample calls. The helper returns only after a second trusted Chromium scrollend and two stable intervals. results-event-order.json and event-order-details.json record times, event traces, fault injection, and scratch module hash.

HTTP503 correction control uses saved scratch fixture and helper modules, with tracked source frozen.
node .scratch/t_p1f3sn00-controls/run-http503.mjs > .scratch/t_p1f3sn00-controls/run-http503.log 2>&1

Background source.refresh under503 returns an undispatched receipt with status503 and snapshot:null, without a new pageerror. Explicit refresh_projection refuses in0.038 seconds and preserves that diagnostic. http503-details.json records the receipts, error arrays, and both scratch module hashes. Root retains the original catalog and focused shell failure evidence separately. No extra catalog run occurred.

Final complete original workspace-utility-pane.run diagnostic passes at6621efe8efef8fa4274cabb42d9e71eb735189cf in95.256 seconds. It uses original App prepare and original run, all shell assertions and final HTTP503 behavior.
node .scratch/t_p1f3sn00-controls/run-full-workspace.mjs > .scratch/t_p1f3sn00-controls/run-full-workspace.log 2>&1

full-workspace/result.json records revision/status/elapsed. full-workspace/artifacts and full-workspace/vps hold original case artifacts. This is a direct diagnostic result, not a catalog receipt. No feedback rerun or subsequent test occurred.

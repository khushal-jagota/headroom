import {build} from '../../web/node_modules/vite/dist/node/index.js';
import {svelte} from '../../web/node_modules/@sveltejs/vite-plugin-svelte/src/index.js';
import {markdownWorkerPlugins} from '../../web/build/markdown-worker.mjs';
import {prepare} from '../../web/tests/browser/cases/workspace-utility-pane.mjs';
import {scratchDirectory,ownedByProcess} from '../../web/tests/support/scratch.mjs';
import {readFile,writeFile,readdir,rm} from 'node:fs/promises';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {resolve,relative,extname} from 'node:path';
const root=process.cwd(), out=resolve('.scratch/t_p1f3sn00-controls/dist'), scratchRoot=await scratchDirectory();
const prepared=await prepare({scratchRoot});
let server;
try {
await build({root:resolve('web'),base:'/',configFile:false,logLevel:'warn',plugins:[svelte()],worker:{plugins:markdownWorkerPlugins},build:{outDir:out,emptyOutDir:true,rollupOptions:{input:prepared.inputs}}});
server=createServer(async(req,res)=>{try {const path=resolve(out,'.'+decodeURIComponent(new URL(req.url,'http://localhost').pathname));if(!path.startsWith(out+'/'))throw Error();const data=await readFile(path);res.writeHead(200,{'content-type':{'.html':'text/html','.js':'text/javascript','.css':'text/css'}[extname(path)]||'application/octet-stream'});res.end(data);}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url=`http://127.0.0.1:${server.address().port}/${relative(resolve('web'),prepared.arguments[0])}`;
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>! /^(PLAN_|PANELS_REAL_)/.test(key)&&!['HERMES_HOME','CODEX_HOME','CLAUDE_CONFIG_DIR','PYTHONPATH','VIRTUAL_ENV'].includes(key)));
const code=await new Promise((resolve,reject)=>{const p=spawn(root+'/.venv/bin/python',[root+'/.scratch/t_p1f3sn00-controls/controls-wheel-final.py',url],{cwd:root,env,stdio:'inherit'});p.on('error',reject);p.on('exit',resolve)});
process.exitCode=code;
}finally {if(server)await new Promise(r=>server.close(r));for(const entry of await readdir(scratchRoot))if(ownedByProcess(entry))await rm(resolve(scratchRoot,entry),{force:true,recursive:true});}

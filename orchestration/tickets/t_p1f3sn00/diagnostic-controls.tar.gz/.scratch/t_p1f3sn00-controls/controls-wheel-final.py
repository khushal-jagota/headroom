import json
import runpy
import sys
import time
import platform
from pathlib import Path
from urllib.parse import parse_qs,urlsplit
from playwright.sync_api import sync_playwright,expect
ROOT=Path.cwd()
OUT=ROOT/'.scratch/t_p1f3sn00-controls'
sys.path.insert(0,str(ROOT))
fixture=runpy.run_path(str(ROOT/'web/tests/support/navigation/browser-fixture.py'))
barriers=runpy.run_path(str(ROOT/'web/tests/browser/support/state_barriers.py'))
results=[]
state={'recap':'Initial recap','id':'control_worker'}
def respond(route):
    parts=urlsplit(route.request.url); path=parts.path
    if path=='/api/navigation/view/snapshot':
        worker={'id':state['id'],'title':'Control worker','worker_type':'coding','stage':'needs_implementation','ticket_status':'agent','recap':state['recap']}
        source=fixture['navigation_response']({'managers':[{'id':'control_manager','title':'Control manager','created_at':1,'tickets':[worker]}]},{'chief_of_staff':{'label':'Chief','conversation_id':'bounded-reader'}})
        route.fulfill(json=fixture['scoped_navigation_response'](source,json.loads(parse_qs(parts.query)['view'][0]))); return
    key=parse_qs(parts.query).get('key',[path])[0] if path=='/api/resource-body' else path
    body={
       '/api/workers/chief-of-staff/settings':{'employee_id':'chief','label':'Chief','recap':'Reader control','skill':None,'launch_defaults':{'employee_backend':'codex','employee_launch_model':None,'employee_launch_reasoning_effort':None}},
       '/api/chief/conversation/start-values':{'backend_key':'codex','model':None,'reasoning_effort':None},
       '/api/worker-types?supported=true':{'worker_types':[]},'/api/worker-types':{'worker_types':[]},'/api/workers':{'workers':[],'chief_of_staff':{'label':'Chief'}},'/api/skills':{'skills':[]},'/api/feedback/count':{'open_count':0},'/api/meta':{'test_mode':True,'app_sha':None},'/api/review':{'items':[],'running_worker_count':0},'/api/deployment-status':{'state':'idle','deployed_sha':None,'target_sha':None,'outcome':None,'detail':None,'valid_until':None},
    }.get(key,{})
    route.fulfill(json={'key':key,'epoch':'controls','revision':'1','body':body} if path=='/api/resource-body' else body)

def record(name,fn,expected_failure=False,contains=None):
    start=time.monotonic()
    try:
        evidence=fn()
        if expected_failure:raise RuntimeError('Expected setup refusal did not occur')
        results.append({'name':name,'status':'expected-success','seconds':time.monotonic()-start,'evidence':evidence})
    except Exception as exc:
        if not expected_failure or (contains and contains not in str(exc)):
            results.append({'name':name,'status':'unexpected-failure','seconds':time.monotonic()-start,'error':repr(exc)})
            (OUT/'results-wheel-final.json').write_text(json.dumps(results,indent=2));raise
        results.append({'name':name,'status':'expected-setup-failure','seconds':time.monotonic()-start,'error':str(exc)})
    (OUT/'results-wheel-final.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results[-1]),flush=True)

with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True)
    context=browser.new_context(viewport={'width':1280,'height':800},reduced_motion='reduce')
    page=context.new_page();page.route('**/api/**',respond)
    page.goto(sys.argv[1]+'?overlay=1#/workspace/chief-of-staff',wait_until='domcontentloaded')
    expect(page.locator('[data-conversation-input]')).to_be_visible()
    pane=page.locator('[data-conversation-pane]')
    if pane.get_attribute('data-conversation-state')!='opened':page.locator('[data-conversation-expand]').click()
    thread=page.locator('[data-conversation-thread]');expect(thread).to_be_visible()
    thread.focus();page.keyboard.press('End')
    page.wait_for_function("()=>{const e=document.querySelector('[data-conversation-thread]');return e&&e.scrollHeight-e.clientHeight-e.scrollTop<=1&&e.dataset.conversationPlacementReady==='true'}")
    thread.hover()
    page.evaluate("()=>{window.__wheelCount=0;window.__suppress=e=>{window.__wheelCount++;e.preventDefault()};document.querySelector('[data-conversation-thread]').addEventListener('wheel',window.__suppress,{capture:true,passive:false})}")
    record('one-suppressed-native-wheel',lambda:barriers['establish_scrollback'](page,lambda:page.mouse.wheel(0,-650),min_clearance=2),True)
    assert page.evaluate('window.__wheelCount')==1
    assert thread.evaluate('e=>e.scrollHeight-e.clientHeight-e.scrollTop')<=1
    page.evaluate("()=>document.querySelector('[data-conversation-thread]').removeEventListener('wheel',window.__suppress,true)")
    record('valid-native-wheel',lambda:barriers['establish_scrollback'](page,lambda:page.mouse.wheel(0,-650),min_clearance=2))
    context.close();browser.close()

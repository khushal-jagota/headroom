import {readFile,writeFile,mkdir,readdir,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createServer} from 'node:http';
import {spawn} from 'node:child_process';
import {resolve,relative,extname} from 'node:path';
import {pathToFileURL} from 'node:url';
const branch=process.cwd(),output=resolve('.scratch/t_p1f3sn00-controls/feedback-attribution');
const trees=[{label:'baseline',root:'/home/vps/projects/panels/worktrees/t_p1f3sn00-feedback-baseline'},{label:'branch',root:branch}];
const hash=data=>createHash('sha256').update(data).digest('hex');
const ownership=[];const results=[];let active,server;
try{
for(const tree of trees){
 const mod=path=>import(pathToFileURL(resolve(tree.root,path)));
 const {build}=await mod('web/node_modules/vite/dist/node/index.js');
 const {svelte}=await mod('web/node_modules/@sveltejs/vite-plugin-svelte/src/index.js');
 const {markdownWorkerPlugins}=await mod('web/build/markdown-worker.mjs');
 const {prepare}=await mod('web/tests/browser/cases/feedback-inbox.mjs');
 const scratch=await mod('web/tests/support/scratch.mjs');
 const scratchRoot=await scratch.scratchDirectory();ownership.push({scratchRoot,scratch});
 const prepared=await prepare({scratchRoot});tree.output=resolve(output,'dist-'+tree.label);
 const sourceHashes={};
 const audit={name:'diagnostic-source-hashes',async generateBundle(options,bundle){for(const chunk of Object.values(bundle)){if(chunk.type!=='chunk')continue;for(const id of Object.keys(chunk.modules)){const path=id.split('?')[0];if(!path.startsWith(tree.root+'/'))continue;try{sourceHashes[relative(tree.root,path)]=hash(await readFile(path));}catch{}}}}};
 const started=performance.now();
 await build({root:resolve(tree.root,'web'),base:'/',configFile:false,logLevel:'warn',plugins:[svelte(),audit],worker:{plugins:markdownWorkerPlugins},build:{outDir:tree.output,emptyOutDir:true,rollupOptions:{input:prepared.inputs}}});
 tree.buildSeconds=(performance.now()-started)/1000;
 tree.sourceHashes=sourceHashes;tree.entry=relative(resolve(tree.root,'web'),prepared.arguments[0]);
 const emitted={};async function collect(dir){for(const item of await readdir(dir,{withFileTypes:true})){const path=resolve(dir,item.name);if(item.isDirectory())await collect(path);else if(['.js','.css'].includes(extname(path)))emitted[relative(tree.output,path)]=hash(await readFile(path));}}
 await collect(tree.output);tree.emittedHashes=emitted;
 await writeFile(resolve(output,tree.label+'-build.json'),JSON.stringify(tree,null,2)+'\n');
}
active=trees[0];
server=createServer(async(req,res)=>{try{const path=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(path.startsWith('/__diagnostic_tree/')){const found=trees.find(tree=>path.endsWith('/'+tree.label));if(!found)throw Error();active=found;res.writeHead(200);res.end(found.label);return;}const file=resolve(active.output,'.'+path);if(!file.startsWith(active.output+'/'))throw Error();const data=await readFile(file);res.writeHead(200,{'content-type':{'.html':'text/html','.js':'text/javascript','.css':'text/css'}[extname(file)]||'application/octet-stream'});res.end(data);}catch{res.writeHead(404);res.end();}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const origin=`http://127.0.0.1:${server.address().port}`;
for(const tree of trees)tree.url=origin+'/'+tree.entry;
if(trees[0].url!==trees[1].url)throw Error('Pair URL differs');
const manifest={output,origin,worker:resolve(output,'case-worker.py'),trees};
const manifestPath=resolve(output,'manifest.json');await writeFile(manifestPath,JSON.stringify(manifest,null,2)+'\n');
const env=Object.fromEntries(Object.entries(process.env).filter(([key])=>! /^(PLAN_|PANELS_REAL_|PANELS_BROWSER_|PANELS_COMPANION_)/.test(key)&&!['HERMES_HOME','CODEX_HOME','CLAUDE_CONFIG_DIR','PYTHONPATH','VIRTUAL_ENV','CONVERSATION_SCROLL_CASE','PANELS_TEST_PYTHON'].includes(key)));
const code=await new Promise((resolve,reject)=>{const p=spawn(branch+'/.venv/bin/python',[output+'/pair.py',manifestPath],{cwd:branch,env,stdio:'inherit'});p.on('error',reject);p.on('exit',resolve)});process.exitCode=code;
}finally{if(server)await new Promise(r=>server.close(r));for(const item of ownership){for(const entry of await readdir(item.scratchRoot))if(item.scratch.ownedByProcess(entry))await rm(resolve(item.scratchRoot,entry),{force:true,recursive:true});}}

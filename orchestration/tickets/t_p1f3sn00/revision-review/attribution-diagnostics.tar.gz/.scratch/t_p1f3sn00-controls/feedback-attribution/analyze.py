import hashlib,json,re,subprocess
from pathlib import Path
BASE=Path('/home/vps/projects/panels/worktrees/t_p1f3sn00-feedback-baseline')
BRANCH=Path.cwd()
OUT=BRANCH/'.scratch/t_p1f3sn00-controls'
normalize=lambda s:re.sub(r'svelte-[a-z0-9]+','svelte-SCOPE',s)
logical=lambda s:re.sub(r'-[A-Za-z0-9_-]{8}(?=\.(?:js|css)$)','-HASH',s)
summary={'attribution':'Inconclusive. Original10.97px failure remains unreproduced. Neither pre-existing nor branch-caused is established.','strict_entrance_limit_pixels':8,'original_failure_pixels':10.969999999999995,'retries':0,'experiments':[],'limits':['One run per tree in each distinct build context. Passing samples cannot rule out a timing-sensitive defect.','Shared-build experiment matches the five original inputs and executes feedback first. Other cases are not executed, and no catalog receipt is produced.','Pair uses the same tracked Chromium process via CDP and identical origin/URL, with fresh contexts and original case clock/input/viewport. Original catalog did not use CDP attachment.','Machine load and Chromium frame scheduling vary despite the same physical host and sequential execution.','Sources and semantic dependency inspection support independence. They do not attribute an unreproduced observed frame jump.'],'baseline_retained':str(BASE)}
for name in ['feedback-attribution','feedback-attribution-shared']:
 root=OUT/name
 builds={k:json.loads((root/f'{k}-build.json').read_text()) for k in ['baseline','branch']}
 rawdiff=[k for k in set(builds['baseline']['sourceHashes'])|set(builds['branch']['sourceHashes']) if builds['baseline']['sourceHashes'].get(k)!=builds['branch']['sourceHashes'].get(k)]
 experiment={'name':name,'source_module_counts':{k:len(v['sourceHashes']) for k,v in builds.items()},'raw_imported_source_differences':rawdiff,'runs':{},'emitted':{}}
 cssmaps={}
 for label in ['baseline','branch']:
  result=json.loads((root/label/'result.json').read_text());caps=json.loads((root/label/'frame-captures.json').read_text());entry=next(c for c in caps if c['setup'].get('stages')==[[0,'ready'],[80,'held']]);frames=entry['frames'];pairs=list(zip(frames,frames[1:]));worst=max(pairs,key=lambda pair:abs(pair[1]['height']-pair[0]['height']))
  experiment['runs'][label]={'result':result,'entrance_max_absolute_delta_pixels':entry['max_absolute_frame_delta'],'entrance_frame_count':len(frames),'worst_pair':worst,'frame_trace':f'{name}/{label}/frame-captures.json','entry_url':builds[label]['entry']}
  dist=root/f'dist-{label}';assets=dist/'assets';start=next(assets.glob('feedback-index*.js'));pending=[start];seen=set()
  while pending:
   file=pending.pop()
   if file in seen:continue
   seen.add(file)
   if file.suffix!='.js':continue
   for _,ref in re.findall(r'''(["'])([^"']+\.(?:js|css))\1''',file.read_text()):
    candidate=(dist/ref.lstrip('/')) if ref.startswith(('/assets/','assets/')) else (file.parent/ref).resolve()
    if candidate.is_file() and candidate not in seen:pending.append(candidate)
  workspace=[str(p.relative_to(dist)) for p in dist.rglob('*.js') if '__heldNavigationFrames' in p.read_text()]
  reachable_workspace=[p for p in workspace if dist/p in seen]
  cssmaps[label]={logical(str(p.relative_to(dist))):hashlib.sha256(normalize(p.read_text()).encode()).hexdigest() for p in seen if p.suffix=='.css'}
  experiment['emitted'][label]={'reachable_feedback_js_css':sorted(str(p.relative_to(dist)) for p in seen),'workspace_host_chunks':workspace,'workspace_host_reachable_from_feedback':reachable_workspace,'all_build_raw_hashes':builds[label]['emittedHashes'],'feedback_css_scope_normalized_sha256':cssmaps[label]}
 experiment['feedback_css_equal_after_scope_normalization']=cssmaps['baseline']==cssmaps['branch']
 summary['experiments'].append(experiment)
files=['web/tests/browser/cases/feedback-inbox.py','web/tests/browser/cases/feedback-inbox.mjs','web/package-lock.json','web/package.json','agent_backends/package-lock.json','requirements.txt','AGENTS.md']
summary['critical_source_hashes']={name:{label:hashlib.sha256((tree/name).read_bytes()).hexdigest() for label,tree in [('baseline',BASE),('branch',BRANCH)]} for name in files}
summary['product_diff']=subprocess.check_output(['git','diff','--name-only','c1d99e049b3d8daa121c21cd0a88ac8d9234d546','974aee1a9541241bc63625ea5fd8d15c84102329','--','web/src','assets'],text=True).splitlines()
(OUT/'feedback-attribution-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for e in summary['experiments']:
 print(e['name'],'css normalized equal',e['feedback_css_equal_after_scope_normalization'])
 for label in ['baseline','branch']:print(label,e['runs'][label]['result']['status'],e['runs'][label]['entrance_max_absolute_delta_pixels'],'workspace reachable',e['emitted'][label]['workspace_host_reachable_from_feedback'])

import json
import os
import socket
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from playwright.sync_api import sync_playwright
manifest=json.loads(Path(sys.argv[1]).read_text())
OUT=Path(manifest['output']);OUT.mkdir(parents=True,exist_ok=True)
with socket.socket() as listener:
    listener.bind(('127.0.0.1',0));port=listener.getsockname()[1]
results=[]
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,args=[f'--remote-debugging-port={port}'])
    endpoint=f'http://127.0.0.1:{port}'
    version=json.loads(urllib.request.urlopen(endpoint+'/json/version').read())
    (OUT/'browser-process.json').write_text(json.dumps({'endpoint':endpoint,'version':version,'same_browser_process_for_both_trees':True,'node_hostname':os.uname().nodename},indent=2))
    try:
        for item in manifest['trees']:
            urllib.request.urlopen(manifest['origin']+'/__diagnostic_tree/'+item['label']).read()
            output=OUT/item['label'];output.mkdir(parents=True,exist_ok=True)
            command=[item['root']+'/.venv/bin/python',manifest['worker'],endpoint,item['url'],str(output)]
            with (output/'run.log').open('w') as stream:
                completed=subprocess.run(command,cwd=item['root'],env=os.environ.copy(),stdout=stream,stderr=subprocess.STDOUT)
            results.append({'label':item['label'],'exit_code':completed.returncode,'command':command,'result':json.loads((output/'result.json').read_text())})
            (OUT/'pair-results.json').write_text(json.dumps(results,indent=2)+'\n')
            print(item['label'],results[-1]['result']['status'],flush=True)
    finally:browser.close()

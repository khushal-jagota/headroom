import hashlib
import importlib.metadata
import inspect
import json
import os
import platform
import runpy
import subprocess
import sys
import time
import traceback
from pathlib import Path
from playwright.sync_api import Page, sync_playwright
ROOT=Path.cwd()
OUT=Path(sys.argv[3]);OUT.mkdir(parents=True,exist_ok=True)
os.environ['PANELS_SIDEBAR_ARTIFACT_DIR']=str(OUT/'artifacts')
sys.path.insert(0,str(ROOT))
original=Page.evaluate
captures=[]
def capture(self,expression,*args,**kwargs):
    result=original(self,expression,*args,**kwargs)
    if expression=='window.__slotFrames' and isinstance(result,list):
        caller=inspect.currentframe().f_back
        labels={k:caller.f_locals[k] for k in ['action','duration','stages'] if k in caller.f_locals}
        captures.append({'sequence':len(captures),'caller':caller.f_code.co_name,'setup':labels,'frames':result})
    return result
Page.evaluate=capture
start=time.monotonic()
result={'revision':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_root':str(ROOT),'status':'failed','host':platform.node(),'python':sys.version,'interpreter':sys.executable,'playwright':importlib.metadata.version('playwright'),'cpu_count':os.cpu_count(),'load_start':os.getloadavg(),'viewport':{'desktop':[1280,844],'phone':[390,844]},'clock':'Original full case uses wall clock except original page.clock.install/fast_forward section. No wrapper timing changes.','gate_receipt':False}
try:
    import planner
    result['planner_source']=planner.__file__
    module=runpy.run_path(str(ROOT/'web/tests/browser/cases/feedback-inbox.py'))
    with sync_playwright() as pw:
        browser=pw.chromium.connect_over_cdp(sys.argv[1])
        result['browser']=browser.version
        prior=list(browser.contexts)
        try:
            module['run'](browser,[sys.argv[2]])
            result['status']='passed'
        except BaseException as exc:
            result['error']=traceback.format_exc()
            result['exception_args']=exc.args
            for context in browser.contexts:
                for page in context.pages:
                    try:
                        frames=original(page,'window.__slotFrames')
                        if frames:result.setdefault('failure_live_frames',[]).append({'url':page.url,'frames':frames})
                    except Exception:pass
        finally:
            for context in browser.contexts:
                if context not in prior:context.close()
finally:
    result['seconds']=time.monotonic()-start
    result['load_end']=os.getloadavg()
    for item in captures:
        pairs=list(zip(item['frames'],item['frames'][1:]))
        item['max_absolute_frame_delta']=max((abs(b['height']-a['height']) for a,b in pairs),default=0)
        item['max_delta_per_16ms']=max((abs(b['height']-a['height'])/max(1,(b['ms']-a['ms'])/16) for a,b in pairs),default=0)
        item['strict_8px_limit_passes']=all(abs(b['height']-a['height'])<8 for a,b in pairs)
    (OUT/'frame-captures.json').write_text(json.dumps(captures,indent=2)+'\n')
    (OUT/'result.json').write_text(json.dumps(result,indent=2,default=repr)+'\n')
    print('FEEDBACK_ATTRIBUTION '+json.dumps(result,default=repr),flush=True)
# The orchestrator always continues to the second tree, even after a real failure.
sys.exit(0 if result['status']=='passed' else 1)
